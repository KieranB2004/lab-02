package com.example.listycity;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import java.util.Arrays;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;
    Button AddButton;
    Button DeleteButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView cityList = findViewById(R.id.city_list);

        String []cities = {"Kyiv", "Lviv", "Poltava", "Odesa"};

        dataList = new ArrayList<>();
        dataList.addAll(Arrays.asList(cities));

        cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, dataList);
        cityList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        cityList.setAdapter(cityAdapter);


        AddButton = (Button) findViewById(R.id.AddButton);
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText EditText = findViewById(R.id.EditText);
                String New_city = EditText.getText().toString().trim();
                EditText.setVisibility(View.VISIBLE);
                if(!New_city.equals("")){
                dataList.add(New_city);
                cityAdapter.notifyDataSetChanged();


                }



            }

        });
        DeleteButton = (Button) findViewById(R.id.DeleteButton);
        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cityList.getCheckedItemPosition() != ListView.INVALID_POSITION){
                    int position_of_click = cityList.getCheckedItemPosition();
                    dataList.remove(position_of_click);
                    cityAdapter.notifyDataSetChanged();


                }


            }

        });


        };
    }
